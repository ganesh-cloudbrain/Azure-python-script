RulesAccountNumbers =  [
        {
            "CustomerID"         : "901274608",
            "CompanyID"          : "80412493",	
            "Type"               : "Expenses",	
            "ExpensesKeyWord"    : "Producción",	
            "CodeTax"            : "",	
            "Percent"            : "",	
            "Account"            : "610505",
        },
        {
            "CustomerID"         : "901274607",
            "CompanyID"          : "900219834",	
            "Type"               : "Tax",	
            "ExpensesKeyWord"    : "",	
            "CodeTax"            : "1",	
            "Percent"            : "",	
            "Account"            : "2400505",
        },
        {
            "CustomerID"         : "901274607",
            "CompanyID"          : "19416973",	
            "Type"               : "Expenses",	
            "ExpensesKeyWord"    : "",	
            "CodeTax"            : "",	
            "Percent"            : "",	
            "Account"            : "511005",
        },
        {
            "CustomerID"         : "901274607",
            "CompanyID"          : "19416973",	
            "Type"               : "WithHolding",	
            "ExpensesKeyWord"    : "Honorarios",	
            "CodeTax"            : "6",	
            "Percent"            : "10",	
            "Account"            : "236505",
        },
        {
            "CustomerID"         : "901274607",
            "CompanyID"          : "19416973",	
            "Type"               : "Tax",	
            "ExpensesKeyWord"    : "",	
            "CodeTax"            : "1",	
            "Percent"            : "",	
            "Account"            : "2400505",
        }
        
        

    ]
						


CODIGO = {
          "5":"RetelVA",
          "6":"ReteFuente",
          "7":"RetelCA",
          "0":"No tiene retenciones",
          }